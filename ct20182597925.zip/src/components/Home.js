import React, { Component } from 'react'

class Home extends Component {
    render() {
        return (
            <div>
             <h6>This is Home Page</h6>   
            </div>
        )
    }
}

export default Home